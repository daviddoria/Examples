function [A B C] = mb2ABC(m, b)

C=1;
B=-1/b;
A=-B*m;
