First run
server 51717

Then run (while 'server' is still running):
client localhost 51717

The client will ask you to type a message. Do this, and press enter. You will see the message appear in the server window!