#include <QtGui>

#include "form.h"

#include "FileSelectionWidget.h"

#include <iostream>
#include <string>

#include <QFileDialog>
#include <QString>

Form::Form(QWidget* parent)
    : QWidget(parent)
{

  this->widget = new FileSelectionWidget(this );
  this->widget->show();

  this->widget_2 = new FileSelectionWidget(this );
  this->widget_2->show();

  setupUi(this);

  this->widget->show();
  this->widget_2->show();
  
  
  FileSelectionWidget* myWidget = static_cast<FileSelectionWidget*>(this->widget);
  myWidget->Test();
  
  
}
