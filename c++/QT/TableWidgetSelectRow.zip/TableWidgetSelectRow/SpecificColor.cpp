
/*
 *
 * The style sheet should look like this to set the selected background color:
 *
 * QTableWidget::item:selected{
background-color:red;
}
QTableWidget::item:selected:!active{
background-color:red;
}
*/