#include <qpushbutton.h>
#include <qapplication.h>

#include "Foo.h"

void MyFunction()
{
  std::cout << "hi" << std::endl;
}

int main(int argc, char **argv)
{
  QApplication a(argc, argv);

  Foo foo;
  QPushButton myButton( "Click me", 0);

  QObject::connect(&myButton, SIGNAL(clicked()), &foo, SLOT(bar()));

  myButton.show();
  return a.exec();
}