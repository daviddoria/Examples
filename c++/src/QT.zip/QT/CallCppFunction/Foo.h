#ifndef FOO_HPP
#define FOO_HPP

#include <qobject.h>
#include <iostream>

void MyFunction();

class Foo : public QObject
{
  Q_OBJECT
  public slots:
    void bar()
    {
      MyFunction();
    }
};


#endif // FOO_HPP