#include <QtGui>

#include "form.h"

#include <iostream>
#include <string>

#include <QFileDialog>
#include <QString>

MainWindow::MainWindow(QMainWindow* parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
    
    connect( this->ui.btnSave, SIGNAL( clicked() ), this, SLOT(btnSave_clicked()) );
    connect( this->ui.btnOpen, SIGNAL( clicked() ), this, SLOT(btnOpen_clicked()) );
}

void MainWindow::btnOpen_clicked()
{
  //get a filename to open
  QString fileName = QFileDialog::getOpenFileName(this,
     tr("Open Image"), "/home/doriad", tr("Image Files (*.png *.jpg *.bmp)"));
  
  std::cout << "Got filename: " << fileName.toStdString() << std::endl;

}

void MainWindow::btnSave_clicked()
{

  //set a filename to save
  QString fileName = QFileDialog::getSaveFileName(this,
     tr("Open Image"), "/home/doriad", tr("Image Files (*.png *.jpg *.bmp)"));
  
  std::cout << "Set filename: " << fileName.toStdString() << std::endl;
}