#ifndef BUTTONFORM_H
#define BUTTONFORM_H

#include "ui_buttonform.h"

class ButtonForm : public QWidget
{
    Q_OBJECT

public:
    ButtonForm(QWidget *parent = 0);

  public slots:
    void pushButton_SetLabelText();

private:
    Ui::ButtonForm ui;
};

#endif
