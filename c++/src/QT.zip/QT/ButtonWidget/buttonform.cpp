#include <QtGui>

#include "buttonform.h"
#include <iostream>

ButtonForm::ButtonForm(QWidget *parent)
    : QWidget(parent)
{
  ui.setupUi(this);
  connect( this->ui.pushButton, SIGNAL( clicked() ), this, SLOT(pushButton_SetLabelText()) );
}

void ButtonForm::pushButton_SetLabelText()
{
  this->ui.label->setText("hello");
}
