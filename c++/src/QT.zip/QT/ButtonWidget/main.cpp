#include <QApplication>

#include "buttonform.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    ButtonForm buttonform;
    
    buttonform.show();
    return app.exec();
}
