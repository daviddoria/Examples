#include <QtGui>

#include "form.h"

Form::Form(QWidget *parent)
    : QWidget(parent)
{
  ui.setupUi(this);
  connect( this->ui.pushButton, SIGNAL( clicked() ), this, SLOT(pushButton_SetLabelText()) );
  connect( this->ui.checkBox, SIGNAL( clicked() ), this, SLOT(checkBox_Clicked()) );
}

void Form::pushButton_SetLabelText()
{
  if(this->ui.checkBox->isChecked())
  {
    this->ui.label->setText("checked");
  }
  else
  {
      this->ui.label->setText("not checked");
  }
  
}

void Form::checkBox_Clicked()
{
  if(this->ui.checkBox->isChecked())
  {
    this->ui.label->setText("checked");
  }
  else
  {
      this->ui.label->setText("not checked");
  }
  
}
